package in.co.canteen.mg.Bean;

public interface DropDownListBean {

	public String getKey();

	public String getValue();

}
